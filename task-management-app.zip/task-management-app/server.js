const express = require("express");
const mongoose = require("mongoose");

const app = express();
const PORT = 5000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve frontend
app.use(express.static("public"));


// =========================
// MongoDB Connection
// =========================

mongoose
    .connect("mongodb://127.0.0.1:27017/thiranex_task_manager")
    .then(() => {
        console.log("MongoDB connected successfully");
    })
    .catch((error) => {
        console.log("MongoDB connection error:", error.message);
    });


// =========================
// Task Schema
// =========================

const taskSchema = new mongoose.Schema({

    title: {
        type: String,
        required: true
    },

    description: {
        type: String,
        required: true
    },

    date: {
        type: String,
        required: true
    },

    status: {
        type: String,
        enum: ["pending", "completed"],
        default: "pending"
    },

    createdAt: {
        type: Date,
        default: Date.now
    }

});


const Task = mongoose.model("Task", taskSchema);


// =========================
// Get All Tasks
// =========================

app.get("/api/tasks", async (req, res) => {

    try {

        const tasks = await Task
            .find()
            .sort({ createdAt: -1 });

        res.json(tasks);

    } catch (error) {

        res.status(500).json({
            message: "Unable to fetch tasks"
        });

    }

});


// =========================
// Create Task
// =========================

app.post("/api/tasks", async (req, res) => {

    try {

        const {
            title,
            description,
            date,
            status
        } = req.body;


        const task = new Task({

            title,
            description,
            date,
            status: status || "pending"

        });


        const savedTask =
            await task.save();


        res.status(201).json(savedTask);

    } catch (error) {

        res.status(500).json({
            message: "Unable to create task"
        });

    }

});


// =========================
// Update Task
// =========================

app.put("/api/tasks/:id", async (req, res) => {

    try {

        const updatedTask =
            await Task.findByIdAndUpdate(
                req.params.id,
                req.body,
                {
                    new: true,
                    runValidators: true
                }
            );


        if (!updatedTask) {

            return res.status(404).json({
                message: "Task not found"
            });

        }


        res.json(updatedTask);

    } catch (error) {

        res.status(500).json({
            message: "Unable to update task"
        });

    }

});


// =========================
// Delete Task
// =========================

app.delete("/api/tasks/:id", async (req, res) => {

    try {

        const deletedTask =
            await Task.findByIdAndDelete(
                req.params.id
            );


        if (!deletedTask) {

            return res.status(404).json({
                message: "Task not found"
            });

        }


        res.json({
            message: "Task deleted successfully"
        });

    } catch (error) {

        res.status(500).json({
            message: "Unable to delete task"
        });

    }

});


// =========================
// Start Server
// =========================

app.listen(PORT, () => {

    console.log(
        `Task Manager running at http://localhost:${PORT}`
    );

});