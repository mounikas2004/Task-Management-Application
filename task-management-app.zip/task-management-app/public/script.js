let tasks = [];

const taskModal = document.getElementById("taskModal");
const taskForm = document.getElementById("taskForm");

const openTaskBtn = document.getElementById("openTaskBtn");
const closeModalBtn = document.getElementById("closeModalBtn");
const cancelBtn = document.getElementById("cancelBtn");

const taskList = document.getElementById("taskList");
const emptyMessage = document.getElementById("emptyMessage");

const searchInput = document.getElementById("searchInput");
const statusFilter = document.getElementById("statusFilter");

const totalTasks = document.getElementById("totalTasks");
const pendingTasks = document.getElementById("pendingTasks");
const completedTasks = document.getElementById("completedTasks");

const modalTitle = document.getElementById("modalTitle");


// Open Add Task Modal
openTaskBtn.addEventListener("click", () => {

    taskForm.reset();

    document.getElementById("taskId").value = "";

    modalTitle.textContent = "Add New Task";

    taskModal.classList.add("show");
});


// Close Modal
function closeModal() {
    taskModal.classList.remove("show");
}

closeModalBtn.addEventListener("click", closeModal);

cancelBtn.addEventListener("click", closeModal);


// Add / Update Task
taskForm.addEventListener("submit", (event) => {

    event.preventDefault();

    const id = document.getElementById("taskId").value;

    const title =
        document.getElementById("taskTitle").value.trim();

    const description =
        document.getElementById("taskDescription").value.trim();

    const date =
        document.getElementById("taskDate").value;

    const status =
        document.getElementById("taskStatus").value;


    if (!title || !description || !date) {
        alert("Please fill in all fields.");
        return;
    }


    // Update existing task
    if (id) {

        const task = tasks.find(
            item => item.id === Number(id)
        );

        if (task) {

            task.title = title;
            task.description = description;
            task.date = date;
            task.status = status;

        }

    }

    // Create new task
    else {

        const newTask = {

            id: Date.now(),

            title: title,

            description: description,

            date: date,

            status: status

        };

        tasks.push(newTask);
    }


    saveTasks();

    renderTasks();

    closeModal();

});


// Display Tasks
function renderTasks() {

    const searchText =
        searchInput.value.toLowerCase().trim();

    const filter =
        statusFilter.value;


    const filteredTasks = tasks.filter(task => {

        const matchesSearch =
            task.title.toLowerCase().includes(searchText) ||
            task.description.toLowerCase().includes(searchText);

        const matchesStatus =
            filter === "all" ||
            task.status === filter;

        return matchesSearch && matchesStatus;

    });


    taskList.innerHTML = "";


    if (filteredTasks.length === 0) {

        taskList.appendChild(emptyMessage);

        emptyMessage.style.display = "block";

    }

    else {

        emptyMessage.style.display = "none";


        filteredTasks.forEach(task => {

            const card =
                document.createElement("div");

            card.className =
                "task-card " +
                (task.status === "completed"
                    ? "completed"
                    : "");


            card.innerHTML = `

                <h3>${escapeHTML(task.title)}</h3>

                <p>
                    ${escapeHTML(task.description)}
                </p>

                <div class="task-info">

                    <span>
                        Due: ${formatDate(task.date)}
                    </span>

                    <span class="status ${task.status}">
                        ${task.status === "completed"
                            ? "Completed"
                            : "Pending"}
                    </span>

                    <div class="task-actions">

                        <button
                            class="complete-btn"
                            onclick="toggleTask(${task.id})"
                        >
                            ${task.status === "completed"
                                ? "Mark Pending"
                                : "Complete"}
                        </button>

                        <button
                            class="edit-btn"
                            onclick="editTask(${task.id})"
                        >
                            Edit
                        </button>

                        <button
                            class="delete-btn"
                            onclick="deleteTask(${task.id})"
                        >
                            Delete
                        </button>

                    </div>

                </div>
            `;


            taskList.appendChild(card);

        });

    }


    updateStatistics();

}


// Edit Task
function editTask(id) {

    const task =
        tasks.find(item => item.id === id);

    if (!task) return;


    document.getElementById("taskId").value =
        task.id;

    document.getElementById("taskTitle").value =
        task.title;

    document.getElementById("taskDescription").value =
        task.description;

    document.getElementById("taskDate").value =
        task.date;

    document.getElementById("taskStatus").value =
        task.status;


    modalTitle.textContent =
        "Edit Task";


    taskModal.classList.add("show");

}


// Complete / Pending
function toggleTask(id) {

    const task =
        tasks.find(item => item.id === id);

    if (!task) return;


    task.status =
        task.status === "completed"
            ? "pending"
            : "completed";


    saveTasks();

    renderTasks();

}


// Delete Task
function deleteTask(id) {

    const confirmDelete =
        confirm("Are you sure you want to delete this task?");

    if (!confirmDelete) return;


    tasks =
        tasks.filter(item => item.id !== id);


    saveTasks();

    renderTasks();

}


// Statistics
function updateStatistics() {

    const total =
        tasks.length;

    const completed =
        tasks.filter(
            task => task.status === "completed"
        ).length;

    const pending =
        tasks.filter(
            task => task.status === "pending"
        ).length;


    totalTasks.textContent = total;

    pendingTasks.textContent = pending;

    completedTasks.textContent = completed;

}


// Save Tasks
function saveTasks() {

    localStorage.setItem(
        "thiranexTasks",
        JSON.stringify(tasks)
    );

}


// Load Tasks
function loadTasks() {

    const savedTasks =
        localStorage.getItem("thiranexTasks");


    if (savedTasks) {

        tasks =
            JSON.parse(savedTasks);

    }


    renderTasks();

}


// Search
searchInput.addEventListener(
    "input",
    renderTasks
);


// Filter
statusFilter.addEventListener(
    "change",
    renderTasks
);


// Format Date
function formatDate(dateString) {

    if (!dateString) return "";

    const date =
        new Date(dateString + "T00:00:00");

    return date.toLocaleDateString(
        "en-IN",
        {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }
    );

}


// Basic HTML protection
function escapeHTML(text) {

    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


// Logout
document.getElementById("logoutBtn")
    .addEventListener("click", () => {

        alert("Logout functionality will be connected with authentication.");

    });


// Start Application
loadTasks();